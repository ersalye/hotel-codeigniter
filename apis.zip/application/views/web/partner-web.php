<?php $this->view('web/header') ?>
      <div class="page-wrapper">
            
          <section class="bg-image space-md" data-image-src="<?php echo base_url(); ?>web-assets/images/profile-banner.jpg" style="background: url(<?php echo base_url(); ?>web-assets/images/profile-banner.jpg) center center / cover no-repeat;">
               <div class="profile">
                  <div class="container">
                     <div class="row">
                        <div class="col-xs-12 col-sm-12  col-lg-12 text-center">
                                <h1 class="font-white text-center">Partner with us</h1> 
								</div>
                        
                     </div>
                  </div>
               </div>
            </section>
            <section class="contact-page inner-page">
               <div class="container">
                  <div class="row">
                     <!-- REGISTER -->
                     <div class="col-md-8">
                        <div class="widget">
						
                           <div class="widget-body"> 
						 
                              <form action="" method="POST">
                                 <div class="row">
								 <div class="form-group col-sm-6">
                                       
                                       <input class="form-control" name="partner" type="text" placeholder="Restaurant Name" required> 
                                    </div>
                                    <div class="form-group col-sm-6">
                                       
                                       <input class="form-control" name="city" type="text"  placeholder="City or Town" required> 
                                    </div>
                                    <div class="form-group col-sm-6">
                                       <input class="form-control" name="address" type="text"  placeholder="Address (Primary Location)" required> 
                                    </div>
									<div class="form-group col-sm-6">
                                      
                                       <input class="form-control" name="title" type="text"  placeholder="Your Title" required> 
                                    </div>
                                    <div class="form-group col-sm-6">
                                      
                                       <input class="form-control" name="first_name" type="text"  placeholder="First Name" required> 
                                    </div>
                                    <div class="form-group col-sm-6">
                                      
                                       <input type="text" name="last_name" class="form-control"  placeholder="Last Name" required> 
									   <!-- <small id="emailHelp" class="form-text text-muted">We"ll never share your email with anyone else.</small>  -->
                                    </div>
                                     <div class="form-group col-sm-6">
                                       
                                       <input class="form-control" name="phone" type="text"  placeholder="Phone Number" required> 
                                    </div>
                                    <div class="form-group col-sm-6">
                                       <input name="email" class="form-control" type="text"  placeholder="Email" required> 
                                    </div>
                                    <div class="form-group col-sm-6">
                                      
                                       <select name="num_locations" class="form-control" required>
            <option value="">Number of locations</option>
              <option value="1">1</option>
              <option value="2-5">2-5</option>
              <option value="6-10">6-10</option>
              <option value="11-25">11-25</option>
              <option value="25+">25+</option>
          </select>
                                    </div>
									<div class="form-group col-sm-6">
                                      <select name="cuisine_type" class="form-control">
            <option value="">Type of cuisine</option>
                <option value="African: Ethiopian">African: Ethiopian</option>
                <option value="African: Other">African: Other</option>
                <option value="Alcohol">Alcohol</option>
                <option value="American">American</option>
                <option value="Asian Fusion">Asian Fusion</option>
                <option value="Asian: Other">Asian: Other</option>
                <option value="Bakery">Bakery</option>
                <option value="Bar / Pub Food">Bar / Pub Food</option>
                <option value="BBQ">BBQ</option>
                <option value="Breakfast &amp; Brunch">Breakfast &amp; Brunch</option>
                <option value="Bubble Tea">Bubble Tea</option>
                <option value="Burgers">Burgers</option>
                <option value="Burmese">Burmese</option>
                <option value="Cajun / Creole">Cajun / Creole</option>
                <option value="Caribbean">Caribbean</option>
                <option value="Chicken">Chicken</option>
                <option value="Chinese: Cantonese">Chinese: Cantonese</option>
                <option value="Chinese: Hot Pot">Chinese: Hot Pot</option>
                <option value="Chinese: Noodles &amp; Dumplings">Chinese: Noodles &amp; Dumplings</option>
                <option value="Chinese: Other">Chinese: Other</option>
                <option value="Chinese: Sichuan">Chinese: Sichuan</option>
                <option value="Chinese: Taiwanese">Chinese: Taiwanese</option>
                <option value="Coffee &amp; Tea">Coffee &amp; Tea</option>
                <option value="Comfort Food">Comfort Food</option>
                <option value="Dessert: Other">Dessert: Other</option>
                <option value="European: Other">European: Other</option>
                <option value="Fish and Chips">Fish and Chips</option>
                <option value="French">French</option>
                <option value="Georgian">Georgian</option>
                <option value="German">German</option>
                <option value="Halal">Halal</option>
                <option value="Ice Cream &amp; Frozen Yogurt">Ice Cream &amp; Frozen Yogurt</option>
                <option value="Indian">Indian</option>
                <option value="Indonesian">Indonesian</option>
                <option value="Italian">Italian</option>
                <option value="Japanese: Other">Japanese: Other</option>
                <option value="Japanese: Ramen">Japanese: Ramen</option>
                <option value="Japanese: Sushi">Japanese: Sushi</option>
                <option value="Juice &amp; Smoothies">Juice &amp; Smoothies</option>
                <option value="Korean">Korean</option>
                <option value="Kosher">Kosher</option>
                <option value="Latin American: Other">Latin American: Other</option>
                <option value="Malaysian">Malaysian</option>
                <option value="Mediterranean">Mediterranean</option>
                <option value="Mexican">Mexican</option>
                <option value="Middle Eastern">Middle Eastern</option>
                <option value="Modern Australian">Modern Australian</option>
                <option value="Pizza">Pizza</option>
                <option value="Russian">Russian</option>
                <option value="Salad / Sandwiches">Salad / Sandwiches</option>
                <option value="Seafood">Seafood</option>
                <option value="Snacks">Snacks</option>
                <option value="Soul Food">Soul Food</option>
                <option value="Southern">Southern</option>
                <option value="Spanish">Spanish</option>
                <option value="Steakhouse">Steakhouse</option>
                <option value="Thai">Thai</option>
                <option value="Vegetarian/Vegan">Vegetarian/Vegan</option>
                <option value="Vietnamese">Vietnamese</option>
                <option value="Wings">Wings</option>
              <!-- ngIf: form.countryCode != 'GB' --><option value="Other" ng-if="form.countryCode != 'GB'" class="ng-scope">Other</option><!-- end ngIf: form.countryCode != 'GB' -->
          </select> 
          </select> 
                                    </div>
									<div class="form-group col-sm-6">
                                       <select name="weekly_orders" class="form-control" required>
            <option value="">Estimated weekly to-go orders</option>
              <option value="1-10">1-10</option>
              <option value="11-25">11-25</option>
              <option value="26-50">26-50</option>
              <option value="51-100">51-100</option>
              <option value="100-500">100-500</option>
              <option value="500+">500+</option>
          </select>
                                    </div>
									<div class="form-group col-sm-6">
                                      <select name="offer_delivery" class="form-control" required>
            <option value="">Do you currently offer delivery?</option>
              <option value="Yes, we have in-house drivers">Yes, we have in-house drivers</option>
              <option value="Yes, we use a delivery service">Yes, we use a delivery service</option>
              <option value="No, but planning to offer soon">No, but planning to offer soon</option>
              <option value="No">No</option>
          </select>
                                    </div>
									
                                   
                                 </div>
                                 
                                 <div class="row">
                                    <div class="col-sm-4"></div>
                                    <div class="col-sm-4">
                                       <p>
		<button type="submit" class="btn theme-btn btn-block">Submit</button> 
									<small id="emailHelp" class="form-text text-muted">We"ll never share your email with anyone else.</small> 

									   </p>
                                    </div>
									<div class="col-sm-4"></div>
                                 </div>
                              </form>
                           </div>
                           <!-- end: Widget -->
                        </div>
                        <!-- /REGISTER -->
                     </div>
                     <!-- WHY? -->
                     <div class="col-md-4">
                        <h4>Registration is fast, easy, and free.</h4>
                        <p>Once you"re registered, you can:</p>
                        <hr>
                        <img src="<?php echo base_url(); ?>web-assets/images/Local.png" alt="" class="img-fluid">
                        <p></p>
                        <div class="panel">
                           <div class="panel-heading">
                              <h4 class="panel-title"><a data-parent="#accordion" data-toggle="collapse" class="panel-toggle collapsed" href="#faq1" aria-expanded="false"><i class="ti-info-alt" aria-hidden="true"></i>How it works</a></h4>
                           </div>
                           <div class="panel-collapse collapse" id="faq1" aria-expanded="false" role="article" style="height: 0px;">
                              <div class="panel-body"> 
							  - If you are the owner of a restaurant, or if you are a user who's discovered a place not listed on Storkks, let us know using this form.<br>

- Once you send the information to us, our awesome content team will verify it. To help speed up the process, please provide a contact number or email address.<br>

- That's it! Once verified the listing will start appearing on Storkks
							  </div>
                           </div>
                        </div>
                        <!-- end:panel 
                        <div class="panel">
                           <div class="panel-heading">
                              <h4 class="panel-title"><a data-parent="#accordion" data-toggle="collapse" class="panel-toggle" href="#faq2" aria-expanded="true"><i class="ti-info-alt" aria-hidden="true"></i>Can I viverra sit amet quam eget lacinia?</a></h4>
                           </div>
                           <div class="panel-collapse collapse" id="faq2" aria-expanded="true" role="article">
                              <div class="panel-body"> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam rutrum ut erat a ultricies. Phasellus non auctor nisi, id aliquet lectus. Vestibulum libero eros, aliquet at tempus ut, scelerisque sit amet nunc. Vivamus id porta neque, in pulvinar ipsum. Vestibulum sit amet quam sem. Pellentesque accumsan consequat venenatis. Pellentesque sit amet justo dictum, interdum odio non, dictum nisi. Fusce sit amet turpis eget nibh elementum sagittis. Nunc consequat lacinia purus, in consequat neque consequat id. </div>
                           </div>
                        </div>-->
                        <!-- end:Panel 
                        <h4 class="m-t-20">Contact Customer Support</h4>
                        <p> If you"re looking for more help or have a question to ask, please </p>
                        <p> <a href="contact.html" class="btn theme-btn m-t-15">contact us</a> </p>-->
                     </div>
                     <!-- /WHY? -->
                  </div>
               </div>
            </section>
		   
		    
        

            <section class="app-section">
               <div class="app-wrap">
                  <div class="container">
                     <div class="row text-img-block text-xs-left">
                        <div class="container">
                           <div class="col-xs-12 col-sm-6 hidden-xs-down right-image text-center">
                              <figure> <img src="<?php echo base_url(); ?>web-assets/images/app.png" alt="Right Image"> </figure>
                           </div>
                           <div class="col-xs-12 col-sm-6 left-text">
                              <h3>The Best Food Delivery App</h3>
                              <p>Now you can make food happen pretty much wherever you are thanks to the free easy-to-use Food Delivery &amp; Takeout App.</p>
                              <div class="social-btns">
                                 <a href="#" class="app-btn apple-button clearfix">
                                    <div class="pull-left"><i class="fa fa-apple"></i> </div>
                                    <div class="pull-right"> <span class="text">Available on the</span> <span class="text-2">App Store</span> </div>
                                 </a>
                                 <a href="#" class="app-btn android-button clearfix">
                                    <div class="pull-left"><i class="fa fa-android"></i> </div>
                                    <div class="pull-right"> <span class="text">Available on the</span> <span class="text-2">Play store</span> </div>
                                 </a>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </section>
            <!-- start: FOOTER -->
            <?php $this->view('web/footer'); ?>
            <!-- end:Footer -->
         </div>
         <!-- end:page wrapper -->
      </div>
      <!--/end:Site wrapper -->
      <!-- Modal -->
    <!--/end:Site wrapper -->
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <script src="<?php echo base_url(); ?>web-assets/js/jquery.min.js"></script>
    <script src="<?php echo base_url(); ?>web-assets/js/tether.min.js"></script>
    <script src="<?php echo base_url(); ?>web-assets/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url(); ?>web-assets/js/animsition.min.js"></script>
    <script src="<?php echo base_url(); ?>web-assets/js/bootstrap-slider.min.js"></script>
    <script src="<?php echo base_url(); ?>web-assets/js/jquery.isotope.min.js"></script>
    <script src="<?php echo base_url(); ?>web-assets/js/headroom.js"></script>
    <script src="<?php echo base_url(); ?>web-assets/js/foodpicky.min.js"></script>
	     	<script type="text/javascript" src="<?php echo base_url(); ?>web-assets/js/notifIt.js"></script>
      <script type="text/javascript" src="<?php echo base_url(); ?>web-assets/js/asidebar.jquery.js"></script>
	  <?php if(!empty($_GET['msg'])){
					  $msg = $_GET['msg'];
					  if($msg=='s'){?>
					  <script>
					  notif({
  msg: "Successfully Submited",
  type: "success"
});
					  </script>
					  
						 			<?php   }}?>

	  <script>
$(document).ready(function(){
$(".forgot").hide();
$(".lfadeout").click(function(){
   $(".loginr").show();
    $(".loginf").hide();
	
    });
$(".lcreate").click(function(){
   
    $(".loginf").show();
	$(".loginr").hide();
	
    });
$(".txt1").click(function(){
   
    $(".forgot").show();
	$(".loginf").hide();
    });

});
</script>	
	  <?php $this->view('web/loginjs-web.php') ?>
</body>

</html>