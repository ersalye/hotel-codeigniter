 <footer class="footer">
            <div class="container">
               <!-- top footer statrs -->
               <div class="row top-footer">
                  <div class="col-xs-12 col-sm-3 footer-logo-block color-gray">
                     <a href="#"> <img src="<?php echo base_url(); ?>web-assets/images/storkks_logo.png" alt="Footer logo"> </a> <span>You Order &amp; We Deliver </span> 
                     <div class="payment-options color-gray">
                        <ul>
                           <li>
                              <a href="#"> <i class="fa fa-facebook-square" aria-hidden="true"></i> </a>
                           </li>
                           <li>
                              <a href="#"> <i class="fa fa-pinterest-square" aria-hidden="true"></i> </a>
                           </li>
                           <li>
                              <a href="#"> <i class="fa fa-instagram" aria-hidden="true"></i> </a>
                           </li>
                           <li>
                              <a href="#"> <i class="fa fa-twitter-square" aria-hidden="true"></i> </a>
                           </li>
                        </ul>
                     </div>
                  </div>
                  <div class="col-xs-12 col-sm-2 about color-gray">
                     <h5>Company</h5>
                     <ul>
                        <li><a href="<?php echo base_url(); ?>about">About us</a> </li>
                        <li><a href="<?php echo base_url(); ?>careers">Careers</a> </li>
                        <li><a href="<?php echo base_url(); ?>Blog">Blog</a> </li>
                     </ul>
                  </div>
                  <div class="col-xs-12 col-sm-2 how-it-works-links color-gray">
                     <h5>Contact</h5>
                     <ul>
                        <li><a href="<?php echo base_url(); ?>help-and-support">Help & Support</a> </li>
                        <li><a href="<?php echo base_url(); ?>partner-with-us">Partner with us</a> </li>
                     </ul>
                  </div>
                  <div class="col-xs-12 col-sm-2 pages color-gray">
                     <h5>Legal</h5>
                     <ul>
                        <li><a href="<?php echo base_url(); ?>terms-and-conditions">Terms & Conditions</a> </li>
                        <li><a href="<?php echo base_url(); ?>refund-policy">Refund & Cancellation</a> </li>
                        <li><a href="<?php echo base_url(); ?>privacy-policy">Privacy Policy</a> </li>
                        <li><a href="<?php echo base_url(); ?>Offers-terms">Offer Terms</a> </li>
                     </ul>
                  </div>
                  <div class="col-xs-12 col-sm-3 pages color-gray">
                     <ul class="social-btns">
                        <li>
                           <a href="#" class="app-btn apple-button clearfix">
                              <div class="pull-left"><i class="fa fa-apple"></i> </div>
                              <div class="pull-right"> <span class="text">Available on the</span> <span class="text-2">App Store</span> </div>
                           </a>
                        </li>
                        <li>
                           <a href="#" class="app-btn android-button clearfix">
                              <div class="pull-left"><i class="fa fa-play" aria-hidden="true"></i> </div>
                              <div class="pull-right"> <span class="text">Available on the</span> <span class="text-2">Google Play</span> </div>
                           </a>
                        </li>
                     </ul>
                  </div>
               </div>
               <!-- top footer ends -->
            </div>
         </footer>