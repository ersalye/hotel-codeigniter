<div class="text-center">
	<h2>Please navigate to the appropriate controller / action to open the associated function with your generated code.</h2>
</div>