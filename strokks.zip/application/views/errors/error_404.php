<?php $this->view('web/header') ?>
  <div class="page-wrapper">
 <section class="bg-image space-md" data-image-src="<?php echo base_url(); ?>web-assets/images/profile-banner.jpg">
               <div class="profile">
                  <div class="container">
                     <div class="row">
                        <div class="col-xs-12 col-sm-12  col-lg-12 text-center">
                                <h1 class="text-center">404 Page Not Found</h1> 
								</div>
                        
                     </div>
                  </div>
               </div>
            </section></div>
  <?php $this->view('web/footer');?>