
<!DOCTYPE html>
<html lang="en" data-textdirection="ltr" class="loading">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Storkks</title>
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i%7COpen+Sans:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">
    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo base_url(); ?>restaurant-assets/images/favicon.png">
    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>restaurant-assets/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>restaurant-assets/css/style.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>restaurant-assets/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>restaurant-assets/css/unslider.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>restaurant-assets/css/style1.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>restaurant-assets/css/morris.css">
    <!-- END VENDOR CSS-->
    <!-- BEGIN STACK CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>restaurant-assets/css/bootstrap-extended.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>restaurant-assets/css/app.min.css">
    <!-- END STACK CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>restaurant-assets/css/vertical-menu.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>restaurant-assets/css/vertical-overlay-menu.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>restaurant-assets/css/style2.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>restaurant-assets/css/palette-gradient.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>restaurant-assets/css/timeline.min.css">
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>restaurant-assets/css/star.rating.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>restaurant-assets/css/froala_editor.pkgd.min.css">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>restaurant-assets/css/style.css">
    
   
</head>
<body>
    <div class="login bg-img" style="background-image: url(<?php echo base_url(); ?>restaurant-assets/images/login-bg.jpg);">
        <div class="login-overlay"></div>
        <div class="login-content">
            
            <div class="login-content-inner">
                
                <form id="login-form" class="form-horizontal" role="form" method="POST" action="">
				<div class="login-head">
                    <h1 class="">Storkks</h1>
                    <h3>Login to Your Shop</h3>
                                    </div>
                    <input type="hidden" name="_token" value="sp3cFNsmDM2QZx9dssMS79Iv2O04uVUu5drQZB9s">
                    <div class="form-group">
                        <label>Email</label>
                         <input id="email" type="email" class="form-control" name="email" placeholder="E-Mail Address" value="" autofocus>
                                            </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input id="password" type="password" class="form-control" placeholder="Password" name="password">
                                            </div>
                    <button class="btn btn-primary btn-block">Login</button>
                    <a href="#" class="forgot-link">Forgot Password?</a>
                   
                </form>
                <form id="forgot-form" class="form-horizontal" role="form" method="POST" action="<?php echo base_url(); ?>Shop/Forgotpassword">
				<div class="login-head">
                    <h1 class="">Storkks</h1>
                    <h3>Forgot Password</h3>
                                    </div>
                    
                    <div class="form-group">
                        <label>Email</label>
                         <input id="forgot-email" type="email" class="form-control" name="email" placeholder="E-Mail Address" value="" autofocus>
                                            </div>
                    
                    <button type="button" id="sendotp" class="btn btn-primary btn-block">Send OTP</button>
                   <a href="" class="forgot-link">Back</a>
                   
                </form>
				<form id="verify-otp" class="form-horizontal" role="form" method="POST" action="">
				<div class="login-head">
                    <h1 class="">Storkks</h1>
                    <h3>Verify OTP</h3>
                                    </div>
                    
                         <input id="emailotp" type="hidden" class="form-control" name="cpassword"  autofocus>
                    <div class="form-group">
                        <label>Verify OTP</label>
                         <input id="otp" type="text" class="form-control" name="cpassword" placeholder="Enter OPT" value="" autofocus>
                                            </div>
                    
                    <button type="button" id="otp-verify" class="btn btn-primary btn-block">Verify OTP</button>
                   
                   <a href="" class="forgot-link">Back</a>
                </form>

				<form id="change-password" class="form-horizontal" role="form" method="POST" action="<?php echo base_url(); ?>Shop/ChangePassword">
				<div class="login-head">
                    <h1 class="">Storkks</h1>
                    <h3>Change Password</h3>
                                    </div>
                    
                    <div class="form-group">
                        <label>Password</label>
                         <input id="c-password" type="password" class="form-control" name="cpassword" placeholder="E-Mail Address" value="" autofocus>
						 <input id="emailchange" type="hidden" class="form-control" name="cpassword" placeholder="Password" value="" autofocus>
                                            </div>
                    <div class="form-group">
                        <label>Confirm Password</label>
                         <input id="cnfm-password" type="password" class="form-control" name="cpassword" placeholder="Conform Password" value="" autofocus>
                                            </div>
                    
                    <button type="button" id="ch-password" class="btn btn-primary btn-block">Change Password</button>
                   <a href="" class="forgot-link">Back</a>
                   
                </form>
            </div>
            
        </div>
    </div>

    <!-- BEGIN VENDOR JS-->
    <script src="<?php echo base_url(); ?>restaurant-assets/js/vendors.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
        
     <!-- BEGIN PAGE LEVEL JS-->
   
   
    
    <script src="<?php echo base_url(); ?>restaurant-assets/js/scripts.js" type="text/javascript">
	</script>
<script type="text/javascript">
   
    $(document).ready(function(){
	$("#forgot-form").hide();
	$("#change-password").hide();
	$("#verify-otp").hide();
	$('.forgot-link').click(function(){
		 $("#login-form").hide();
		 $("#forgot-form").show();
	 });

	
	 $('#sendotp').click(function(){
		 var email = $("#forgot-email").val();
			$.ajax({
			url : "<?php echo site_url('Shop/Forgotpassword');?>",
			method : "POST",
			dataType: 'json',
			data : {email: email},
			success: function(data){
				if(data.msg == 1){
					 $("#forgot-form").hide();
					$("#verify-otp").show();
					$("#emailotp").val(email);
				}else{
					alert('Enter registered email');
				}
				console.log(data.msg);
			}
			});
	 });
	 $('#otp-verify').click(function(){
		 var emailotp = $("#emailotp").val();
		 var otp = $("#otp").val();
			$.ajax({
			url : "<?php echo site_url('Shop/VerifyOtp');?>",
			method : "POST",
			dataType: 'json',
			data : {email: emailotp,otp:otp},
			success: function(data){
				if(data.msg == 1){
					 $("#verify-otp").hide();
					$("#change-password").show();
					$("#emailchange").val(emailotp);
				}else{
					alert('Enter valid OTP');
				}
				console.log(data.msg);
			}
			});
	 });	
	 $('#ch-password').click(function(){
		 var cemail = $("#emailchange").val();
		 var password = $("#c-password").val();
		 var cpassword = $("#cnfm-password").val();
		 if(password==cpassword){
			$.ajax({
			url : "<?php echo site_url('Shop/ChangePassword');?>",
			method : "POST",
			dataType: 'json',
			data : {email: cemail,password:password},
			success: function(data){
				if(data.msg == 1){
					alert('Password Succefully Updated');
					 location.reload();
				}else{
					alert('Enter Fail');
				}
				console.log(data.msg);
			}
		 });
		 }else{
			 alert('Password Not Matched');
		 }
	 });	
	});
	</script>

</body>
</html>